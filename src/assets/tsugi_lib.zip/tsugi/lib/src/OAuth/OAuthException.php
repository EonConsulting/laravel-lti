<?php
// vim: foldmethod=marker

namespace Tsugi\OAuth;

$OAuth_last_computed_siguature = false;

/* Generic exception class
 */
class OAuthException extends \Exception {
  // pass
}
